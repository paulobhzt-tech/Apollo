/* Only the static, public build is cached. API and session data stay out of CacheStorage. */
const CACHE = "apollo-public-v5-a5d0325b871bfe0d37423f8b6e9b837f38958b829a13376ae02227306c409dc4";
const ASSETS = {"/apple-touch-icon.png":"sha256-ay90VFUyiIg43l+xMExMyqBf6pGXdhRT/rgdr1GQFic=","/assets/ibm-plex-mono-cyrillic-400-normal-BSMlKf0J.woff2":"sha256-djVCK9EN27yw4MqhFUuSgpj1yDGbjACzCXjUOV9Hg84=","/assets/ibm-plex-mono-cyrillic-400-normal-CEL4l2ZJ.woff":"sha256-QtqBoou83dpnaKJaSzEF7ikeadX6bHR0e8UbvGcYxTg=","/assets/ibm-plex-mono-cyrillic-500-normal-Ael50iVv.woff":"sha256-VaOvXlug9WW05mFJz+B3uoisQsw/aGUKkB1Y6tv5zZs=","/assets/ibm-plex-mono-cyrillic-500-normal-Bq9vWWag.woff2":"sha256-HYlGLobLjofn6db2Y1YFvXwwgbrKbKrs7oSRa/e2Dtw=","/assets/ibm-plex-mono-cyrillic-ext-400-normal-DMdlQ8Kv.woff":"sha256-Dkojk+jtMYWuMA5KICttkUnUfYoOW7jx0dsz52uG7NE=","/assets/ibm-plex-mono-cyrillic-ext-400-normal-xuaO2J-f.woff2":"sha256-+MIuwYBL1pZrcPQ6x8MnAlZFtMCVlxF/yipabHUBBv4=","/assets/ibm-plex-mono-cyrillic-ext-500-normal-BIfNGwUT.woff":"sha256-6tssQnhZsYV2E4AUPR9CGH/Xy9lHBLVD5MdsY2j7q1I=","/assets/ibm-plex-mono-cyrillic-ext-500-normal-BqneJy0T.woff2":"sha256-P+vlx/IuSwe0VSc4Zzw9vovO0txfSLhm7ffM2VUtEJo=","/assets/ibm-plex-mono-latin-400-normal-CvHOgSBP.woff":"sha256-Mo1QtuzpyiXEbuo+iFukl/Yjfy+4Tve5L4jhShol44E=","/assets/ibm-plex-mono-latin-400-normal-DMJ8VG8y.woff2":"sha256-CJSfco3FLVKOabFmfRXImlaGpO6aKW/5CYOYX5nDgPc=","/assets/ibm-plex-mono-latin-500-normal-CB9ihrfo.woff":"sha256-CfAYxYVW5YAezEnVtSddz/THMxHCr2uI4xxR120Hap0=","/assets/ibm-plex-mono-latin-500-normal-DSY6xOcd.woff2":"sha256-AdKFRHQJyKWIaSFiQ5oDi4y9eHEwnuICZ7DS2RxujiI=","/assets/ibm-plex-mono-latin-ext-400-normal-BmRBH3aV.woff2":"sha256-a8DyJqW3iEqBcOP2LGPXZ1YJ1GMb3Fkxtc2rgYIfAOs=","/assets/ibm-plex-mono-latin-ext-400-normal-D3D2R8hC.woff":"sha256-+N2qCrnTwFLJ/gNXUcghS34NWebntpsEX4ZZwv5NztI=","/assets/ibm-plex-mono-latin-ext-500-normal-CAhNIIs5.woff2":"sha256-a7BkB8l1hLCGepWeBeiHRpO/64wxfeGQgRxRWY8tmeo=","/assets/ibm-plex-mono-latin-ext-500-normal-CZ70TYgx.woff":"sha256-/12onD7iDTg1mUO2GnqukgDSoPYc+VyhCnzM74HaL/U=","/assets/ibm-plex-mono-vietnamese-400-normal-BulugwFq.woff2":"sha256-YmMrY3UwXnDdyv3YlSGOauQaGE/NKAppxzlGBgTKAKk=","/assets/ibm-plex-mono-vietnamese-400-normal-DDuiU_S-.woff":"sha256-vO1WHZkeP4HBUMCOcff6hJ/L/1I1YPYFkkXy7c4ZtgA=","/assets/ibm-plex-mono-vietnamese-500-normal-C8zxqsMH.woff":"sha256-dV9itBjfF1GKoOoWtCMuVGzpSaSresxXcHH6m+nj3Ig=","/assets/ibm-plex-mono-vietnamese-500-normal-DZ4AoWbu.woff2":"sha256-eBYz2V3ogED7dxQdHmXZKMh8AURpH7x02lpk0Ten6RA=","/assets/index-CpzcCkZI.css":"sha256-3L6byLah3ak3ZR9eYK1WvMiLTYkzmdIAdPF0C5q+kTU=","/assets/index-Cqz1rttC.js":"sha256-5EU5Bh0y9PhW39H5Flv3HhZ+gBkUlHTkuRRi3f489l0=","/assets/outfit-latin-ext-wght-normal-DdQaqQDo.woff2":"sha256-D1PRwDs5GNdEqEO1A5AB7jFpXKHiVeORQYjfgb60Yek=","/assets/outfit-latin-wght-normal-Bc-8i84L.woff2":"sha256-bBjVef2Hw3dr4Gi3YsvIP946y1Q9Seq9Ot6ELrmH6Ic=","/assets/plus-jakarta-sans-latin-ext-wght-normal-DmpS2jIq.woff2":"sha256-OOO4/YBFBI6zEdkBcKRCntLI9AWFLcPZG1r4RSdYcD8=","/assets/plus-jakarta-sans-latin-wght-normal-eXO_dkmS.woff2":"sha256-FT/IW3Api+6x1hpfcjMxZJ5/I7t3MCpm5hyz4vvbXnk=","/assets/plus-jakarta-sans-vietnamese-wght-normal-qRpaaN48.woff2":"sha256-snXRJYYB3aJA/GodSmytVuaR2Jj1zfGw5P1soAItjkA=","/index.html":"sha256-dXw6t8Qxdd3SPmEqX9gaXOG3oaawixd+bP32qBispuk=","/manifest.webmanifest":"sha256-ORBDoqJMr3OBOP/FoKMPsGbjubem6bksG3psgldupIE=","/offline.html":"sha256-++Z2ZCk/+guoFoga2exDQUJvdQS+Ce1ZKw8nUr7gDlQ="};
const SHELL_ROUTES = new Set(['/', '/login', '/pdv', '/mesas', '/comanda-mobile', '/mesas-offline']);

self.addEventListener('install', event => {
  // Let open tabs finish with the worker and assets they loaded.
  event.waitUntil((async () => {
    if (!CACHE || !ASSETS) throw new Error('Apollo: missing build asset list');
    const cache = await caches.open(CACHE);
    await cache.addAll(Object.entries(ASSETS).map(([url, integrity]) => new Request(url, {
      cache: 'reload',
      credentials: 'omit',
      redirect: 'error',
      integrity,
    })));
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('apollo-public-') && key !== CACHE)
      .map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

async function navigate(request, pathname) {
  let networkResponse;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    networkResponse = await fetch(request, { cache: 'no-store', signal: controller.signal });
    if (![502, 503, 504].includes(networkResponse.status)) return networkResponse;
  } catch {
    // Transport failure takes the same path as a gateway outage.
  } finally {
    clearTimeout(timeout);
  }

  const cache = await caches.open(CACHE);
  const path = pathname.replace(/\/+$/, '').toLowerCase() || '/';
  const shell = SHELL_ROUTES.has(path);
  const cached = (shell && await cache.match('/index.html')) || await cache.match('/offline.html');
  if (!cached) return networkResponse || Response.error();

  // A synthetic response keeps the navigation's original URL in the document,
  // including in engines that propagate the URL of a cached fetch response.
  const headers = new Headers(cached.headers);
  headers.delete('content-encoding');
  headers.delete('content-length');
  headers.set('x-apollo-offline-fallback', shell ? 'shell' : 'notice');
  return new Response(cached.body, { headers });
}

self.addEventListener('fetch', event => {
  const request = event.request;
  const { origin, pathname } = new URL(request.url);
  if (!ASSETS || request.method !== 'GET' || origin !== self.location.origin ||
      pathname === '/api' || pathname.startsWith('/api/')) return;

  if (request.mode === 'navigate') {
    event.respondWith(navigate(request, pathname));
  } else if (Object.hasOwn(ASSETS, pathname)) {
    event.respondWith(caches.open(CACHE).then(cache => cache.match(pathname)).then(response => response || fetch(request, {
      cache: 'reload',
      credentials: 'omit',
      redirect: 'error',
      integrity: ASSETS[pathname],
    })));
  }
});
